package com.example.microfono20

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var mainLayout: ConstraintLayout
    private lateinit var btnMic: Button  // Cambiado a Button
    private lateinit var btnExit: Button // Cambiado a Button
    private val REQUEST_CODE_SPEECH_INPUT = 1

    // Solicitud de permisos
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            startVoiceRecognition()
        } else {
            Toast.makeText(this, "Permiso de micrófono denegado", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mainLayout = findViewById(R.id.mainLayout)
        btnMic = findViewById(R.id.btnMic) // Asegurarse de que se refiere a Button
        btnExit = findViewById(R.id.btnExit)

        // Botón de micrófono para reconocimiento de voz
        btnMic.setOnClickListener {
            checkMicrophonePermission()
        }

        // Botón para salir de la aplicación
        btnExit.setOnClickListener {
            finish()
        }
    }

    // Verificar permisos de micrófono
    private fun checkMicrophonePermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED) {
            startVoiceRecognition()
        } else {
            // Solicitar permiso si no se ha concedido
            requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Diga un color")

        try {
            startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT)
        } catch (e: Exception) {
            Toast.makeText(this, "El reconocimiento de voz no está disponible", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_CODE_SPEECH_INPUT && resultCode == RESULT_OK && data != null) {
            val result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = result?.get(0)?.lowercase(Locale.getDefault())

            // Cambiar color según el texto reconocido
            when (spokenText) {
                "rojo" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorRed))
                "verde" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorGreen))
                "azul" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorBlue))
                "amarillo" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorYellow))
                "naranja" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorOrange))
                "morado" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorPurple))
                "blanco" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorWhite))
                "negro" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorBlack))
                "gris" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorGray))
                "rosa" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorSecondary))
                "cyan" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorAccent))
                "violeta" -> mainLayout.setBackgroundColor(resources.getColor(R.color.colorSecondaryLight))
                // Agrega más colores secundarios si lo deseas

                else -> Toast.makeText(this, "El color \"$spokenText\" no está disponible", Toast.LENGTH_LONG).show()
            }
        }
    }
}
